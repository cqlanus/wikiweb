chrome.devtools.panels.create(
    "wikiweb",
    "web.png",
    "index.html",
    function() {

    }
);
